require({cache:{
'url:epi-cms/contentediting/editors/templates/LinkItemEditor.html':"﻿<div data-dojo-attach-point=\"inputContainer\" class=\"dijitReset dijitInputField dijitInline epi-resourceInputContainer\" id=\"widget_${id}\">\r\n    <div data-dojo-attach-point=\"displayNode, dropAreaNode, stateNode\" class=\"dijit dijitReset dijitInline dijitInlineTable dijitLeft dijitTextBox displayNode\">\r\n        <div class=\"dijitReset dijitLeft dijitInputField dijitInputContainer\">\r\n            <div data-dojo-attach-point=\"contentSelectorContainer\" class=\"contentSelectorContainer\"></div>\r\n            <div class=\"epi-linkItemContainer\">\r\n                <span class=\"epi-iconLink\"></span>\r\n                <span data-dojo-attach-point=\"iconNode\"></span>\r\n                <div data-dojo-attach-point=\"resourceName\" class=\"dijitInline epi-resourceName dojoxEllipsis\" >\r\n                    <span data-dojo-attach-point=\"selectedContentNameNode\"></span>\r\n                    <span data-dojo-attach-point=\"selectedContentLinkNode\"></span>\r\n                </div>\r\n                <div data-dojo-attach-point=\"extraIconsContainer\" class=\"epi-extraIconsContainer\">\r\n                    <span data-dojo-attach-point=\"iconNodeMenu\" class=\"epi-iconContextMenu\" />\r\n                </div>\r\n                <div data-dojo-attach-point=\"clearButton\"></div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>\r\n"}});
define("epi-cms/contentediting/editors/LinkItemEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    // epi-cms
    "epi-cms/widget/_SelectorBase",
    "epi-cms/contentediting/viewmodel/LinkItemModel",
    "epi-cms/contentediting/viewmodel/ItemCollectionViewModel",
    "epi-cms/widget/SingleLinkEditor",
    "epi-cms/dgrid/formatters",
    "epi-cms/widget/_ContentSelectorActionsMixin",

    // resources
    "dojo/text!./templates/LinkItemEditor.html",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.editlink"
], function (
    // dojo
    declare,
    lang,

    // epi-cms
    _SelectorBase,
    LinkItemModel,
    ItemCollectionViewModel,
    SingleLinkEditor,
    formatters,
    _ContentSelectorActionsMixin,

    // resources
    template,
    resource
) {

    return declare([_SelectorBase, _ContentSelectorActionsMixin], {

        resource: resource,

        baseClass: "epi-linkItemEditor",

        templateString: template,

        itemModelType: LinkItemModel,

        dialogContentClass: SingleLinkEditor,

        postMixInProperties: function () {

            this.actionsNodeOptions = {
                settings: {
                    label: resource.buttonlabel
                }
            };

            if (this.customTypeIdentifier) {
                this.allowedDndTypes.unshift(this.customTypeIdentifier);
            }

            this.own(
                this.model = this.model || new ItemCollectionViewModel(this.value ? [this.value] : [], {
                    itemModelType: this.itemModelType,
                    readOnly: this.readOnly
                }),
                this.model.on("changed", function () {
                    var value = this.get("value");
                    value = value === undefined ? null : value;
                    this._updateDisplayNode(value ? Object.assign({}, value, { name: value.text }) : null);
                    this.onChange(value);
                }.bind(this))
            );

            this.inherited(arguments);
        },

        postCreate: function () {
            this.inherited(arguments);

            this.own(this.model.on("initCompleted", this._initialize.bind(this)));
            this._initialize();
        },

        _updateDisplayNode: function (content) {
            // summary:
            //      Override to set icon class

            this.inherited(arguments);

            // Reset icon class
            this.iconNode.className = "";
            if (content) {
                var additionalClass = formatters.additionalClassByFilename(content.text);
                this.iconClass = formatters.contentIconClass(content.typeIdentifier, additionalClass);
                this.iconNode.className = this.iconClass;

                //change the title from "{name}, ID: {contentLink} (Type: {contentTypeName})" to show resource name only if 'content' is not content.
                if (!content.contentLink) {
                    this.resourceName.title = this.resourceName.textContent.trim();
                }
            }
        },

        _initialize: function () {
            var value = this.get("value");
            this.model.set("selectedItem", value);
            this._updateDisplayNode(value ? Object.assign({}, value, { name: value.text }) : null);
            this._editItemCommand && this._editItemCommand.set("model", this.model);
            if (this._waitToFireOnChange) {
                this._waitToFireOnChange = false;
                this.onChange(value);
            }
        },

        _setupDialogSettings: function () {
            // summary:
            //      Setup settings for dialog.
            // tags:
            //      protected virtual

            this.inherited(arguments);

            this.dialogSettings = Object.assign(this.dialogSettings, {
                title: this._getTitle(),
                dialogContentClass: this.dialogContentClass
            });
        },

        _setupContentSelectorDialogSettings: function () {
            this.inherited(arguments);

            this.contentSelectorDialogSettings = Object.assign(this.contentSelectorDialogSettings, {
                modelType: this.metadata.additionalValues["modelType"],
                hiddenFields: this.hiddenFields,
                getCurrentValue: this.getCurrentValue.bind(this)
            });
        },

        getCurrentValue: function () {
            return this.get("value");
        },

        _onDialogExecute: function (linkObj) {
            //summary:
            //    Handle dialog close through executing OK, Cancel, Delete commands
            // tags:
            //    protected

            this.set("value", linkObj);
            this._waitToFireOnChange = true;
        },

        _setValueAttr: function (value) {
            if (!value || (value instanceof Array) && value.length === 0) {
                value = null;
            }

            this.model && this.model.set("data", value ? [value] : []);
        },

        _getValueAttr: function () {
            if (!this.model) {
                return null;
            }

            var value = this.model.get("value");
            if (value instanceof Array && value.length === 0) {
                return null;
            }

            return value && value[0];
        },

        isValid: function () {
            return (!this.required || this.get("value"));
        },

        getEmptyValue: function () {
            // summary:
            //    Returns empty property value
            //    Overriden from _HasClearButton
            //
            // tags:
            //    public callback

            return null;
        },

        onDrop: function (value) {
            // summary:
            //    Triggered when something has been dropped onto the widget.
            //    Overriden from _Droppable
            //
            // tags:
            //    public callback

            this._waitToFireOnChange = true;
        },

        _getTitle: function () {
            // summary:
            //      Customize base get method for title prop.
            // tags:
            //      protected

            return lang.replace(this.value ? this.resource.title.template.edit : this.resource.title.template.create, this.resource.title.action);
        }

    });
});
