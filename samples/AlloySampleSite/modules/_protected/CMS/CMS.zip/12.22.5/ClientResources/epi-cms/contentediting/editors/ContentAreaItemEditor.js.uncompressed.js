define("epi-cms/contentediting/editors/ContentAreaItemEditor", [
    "dojo/_base/declare",
    "./_ContentAreaTree",
    "./ContentAreaEditor"

], function (
    declare,
    _ContentAreaTree,
    ContentAreaEditor
) {
    var _ContentAreaItemTree = declare([_ContentAreaTree], {
        checkItemAcceptance: function () {
            return false;
        }
    });

    return declare([ContentAreaEditor], {
        // tags:
        //      internal

        baseClass: "epi-content-area-wrapper epi-content-area-item-editor",

        treeClass: _ContentAreaItemTree,

        allowMultipleItems: false,

        postMixInProperties: function () {
            this.inherited(arguments);

            this.movePrevious.set("isAvailable", false);
            this.moveNext.set("isAvailable", false);
        },

        _setupContentSelector: function () {
            this.inherited(arguments);

            this._toggleSelector();
        },

        _startDrag: function (source, nodes) {
            if (nodes && nodes.length > 1) {
                this.domNode.classList.add("dojoDndTargetDisabled");
                return;
            }

            var isReorderingItems = this.tree && source === this.tree.dndController;
            if (isReorderingItems) {
                return this.inherited(arguments);
            }
            var hasReachedLimit = this.model.get("value").length === 1;
            if (hasReachedLimit) {
                this.domNode.classList.add("dojoDndTargetDisabled");
                return;
            }

            return this.inherited(arguments);
        },

        onForceChange: function (valueArray) {
            this.onChange(valueArray && valueArray.length > 0 ? valueArray[0] : null);
            this._toggleSelector();
        },

        // _checkAcceptance: function (source, nodes) {
        //     if (nodes && nodes.length >= 1) {
        //         return false;
        //     }
        //
        //     var currentValue = this.model.get("value");
        //     if (currentValue && currentValue.length > 0) {
        //         return false;
        //     }
        //
        //     return this.inherited(arguments);
        // },

        _setValueAttr: function (value) {
            if (Array.isArray(value) || !value) {
                this.inherited(arguments);
            } else {
                this.set("value", [value]);
            }
        },

        _getValueAttr: function () {
            var value = this.value;
            if (Array.isArray(value)) {
                return value[0];
            } else {
                return value;
            }
        },

        _toggleSelector: function () {
            if (this.get("readOnly")) {
                return;
            }

            var isDisabled = (this.model.get("value") || []).length >= 1;
            this.actionsContainer.classList.toggle("dijitHidden", isDisabled);
        },

        _isPersonalizationEnabled: function () {
            return false;
        }
    });
});
