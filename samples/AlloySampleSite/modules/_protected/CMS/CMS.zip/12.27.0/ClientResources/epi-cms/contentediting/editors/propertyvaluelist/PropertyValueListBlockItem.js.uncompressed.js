require({cache:{
'url:epi-cms/contentediting/editors/propertyvaluelist/templates/CollapsiblePropertyValueListItem.html':"<div class=\"epi-property-value-list__item collapsible\">\r\n    <div class=\"epi-property-value-list__index\"></div>\r\n    <div class=\"epi-property-value-list__content\">\r\n        <div class=\"header\">\r\n            <div class=\"title\">\r\n                <div class=\"expander\" data-dojo-attach-point=\"expander\">\r\n                    <span class=\"dijitArrowButtonInner dijitRightArrowButton\" data-dojo-attach-point=\"expanderIcon\"></span>\r\n                    <span data-dojo-attach-point=\"headerNode\"></span>\r\n                </div>\r\n            </div>\r\n            <span class=\"dijitIcon epi-iconContextMenu\"></span>\r\n        </div>\r\n        <div class=\"block-data-container hidden\" data-dojo-attach-point=\"containerNode\"></div>\r\n    </div>\r\n</div>\r\n"}});
﻿define("epi-cms/contentediting/editors/propertyvaluelist/PropertyValueListBlockItem", [
    // dojo
    "dojo/_base/declare",
    "dojo/dom-construct",
    "dojo/on",
    "dojo/aspect",
    // dijit
    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/_TemplatedMixin",
    "epi/shell/DestroyableByKey",
    "./PropertyValueListBlockEditFormContainer",
    // resources
    "dojo/text!./templates/CollapsiblePropertyValueListItem.html"
], function (
    // dojo
    declare,
    domConstruct,
    on,
    aspect,
    // dijit
    _WidgetBase,
    _Container,
    _TemplatedMixin,
    DestroyableByKey,
    PropertyValueListBlockEditFormContainer,
    // resources
    collapsibleTemplate
) {
    return declare([_WidgetBase, _Container, _TemplatedMixin, DestroyableByKey], {
        // summary:
        //      The view for the PropertyValueListBlockItem.
        // tags:
        //      internal

        templateString: collapsibleTemplate,

        // metadata: [readonly] Object
        //      Metadata of the list item
        metadata: null,

        expander: null,
        expanderIcon: null,
        expanded: false,

        buildRendering: function () {
            this.inherited(arguments);
            this.editor = new PropertyValueListBlockEditFormContainer({
                metadata: this.metadata,
                doLayout: false
            });
            domConstruct.place(this.editor.domNode, this.containerNode);
            var initialValue = this.metadata.settings.value;
            this.editor.set("value", initialValue);
            this.headerNode.innerHTML = this.listItemHeaderFormatter(initialValue);
            if (this._started && !this.editor._started) {
                this.editor.startup();
            }

            this.own(aspect.after(this.editor, "onChange", function (value) {
                return Object.assign(value, { contentTypeGuid: this.metadata.settings[this.metadata.settings.contentTypeGuidKeyName] });
            }.bind(this), true));

            this.own(on(this.expander, "click", this.expand.bind(this)));
        },

        getDisplayedValue: function () {
            return "";
        },

        isValid: function () {
            return this.editor.isValid();
        },

        expand: function () {
            this.expanded = !this.expanded;
            this.expanderIcon.classList.toggle("dijitRightArrowButton");
            this.containerNode.classList.toggle("hidden");
            if (this.expanded) {
                this.ownByKey("changedHandler", this.editor.on("change", function (formValue) {
                    this.onStartEdit();
                    this.onChange(formValue);
                    this.onStopEdit();
                    this.headerNode.innerHTML = this.listItemHeaderFormatter(formValue);
                }.bind(this)));
            } else {
                this.destroyByKey("changedHandler");
            }
        },

        onChange: function (value) {
            // summary:
            //      callback method called when the value has changed
            //  tags:
            //      public
        },

        onStartEdit: function () {
            // summary:
            //      callback method called when editor is activated
            //  tags:
            //      public
        },

        onStopEdit: function () {
            // summary:
            //      callback method called when editor is no longer active
            //  tags:
            //      public
        }
    });
});
