define("epi-cms/command/Spliter", [
    "dojo/_base/declare",
    "epi/shell/command/_Command"
], function (
    declare,
    _Command
) {
    return declare([_Command], {
        isAvailable: false,
        category: "menuWithSeparator",
        isSplitter: true
    });
});
