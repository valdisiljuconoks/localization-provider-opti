define(
"dojox/atom/widget/nls/da/FeedEntryViewer", ({
	displayOptions: "[visningsindstillinger]",
	title: "Titel",
	authors: "Forfattere",
	contributors: "Bidragydere",
	id: "Id",
	close: "[luk]",
	updated: "Opdateret",
	summary: "Resumé",
	content: "Indhold"
})
);
