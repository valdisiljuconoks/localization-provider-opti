define(
"dojox/atom/widget/nls/ar/FeedEntryViewer", ({
	displayOptions: "[اختيارات العرض]",
	title: "العنوان",
	authors: "المؤلفين",
	contributors: "المساهمين",
	id: "الكود",
	close: "[اغلاق]",
	updated: "تحديث في",
	summary: "الملخص",
	content: "المحتويات"
})
);
