//>>built
define("dojox/atom/widget/nls/hu/FeedViewerEntry",({deleteButton:"[Törlés]"}));