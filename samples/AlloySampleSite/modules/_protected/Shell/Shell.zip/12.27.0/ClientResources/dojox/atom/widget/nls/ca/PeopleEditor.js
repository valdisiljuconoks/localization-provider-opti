//>>built
define("dojox/atom/widget/nls/ca/PeopleEditor",({add:"Afegeix",addAuthor:"Afegeix un autor",addContributor:"Afegeix un col·laborador"}));