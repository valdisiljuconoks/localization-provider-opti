//>>built
define("epi/obsolete",[],function(){return function(_1,_2,_3){var _4="OBSOLETE: "+_1;if(_2){_4+=" "+_2;}if(_3){_4+=" -- will be removed in version: "+_3;}console.warn(_4);};});