//>>built
define("dojox/atom/widget/nls/it/FeedEntryEditor",({doNew:"[nuovo]",edit:"[modifica]",save:"[salva]",cancel:"[annulla]"}));