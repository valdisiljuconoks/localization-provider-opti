//>>built
define("dojox/atom/widget/nls/az/PeopleEditor",({"add":"Əlavə Et","addAuthor":"Yazıçı Əlavə Et","addContributor":"Əməyi keçənlərə Əlavə Et"}));