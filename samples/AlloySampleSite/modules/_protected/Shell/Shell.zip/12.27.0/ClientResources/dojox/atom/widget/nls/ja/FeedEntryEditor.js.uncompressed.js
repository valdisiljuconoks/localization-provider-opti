define(
"dojox/atom/widget/nls/ja/FeedEntryEditor", ({
	doNew: "[新規]",
	edit: "[編集]",
	save: "[保存]",
	cancel: "[キャンセル]"
})
);
