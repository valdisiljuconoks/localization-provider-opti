//>>built
define("dojox/atom/widget/nls/az/FeedViewerEntry",({"deleteButton":"[Sil]"}));