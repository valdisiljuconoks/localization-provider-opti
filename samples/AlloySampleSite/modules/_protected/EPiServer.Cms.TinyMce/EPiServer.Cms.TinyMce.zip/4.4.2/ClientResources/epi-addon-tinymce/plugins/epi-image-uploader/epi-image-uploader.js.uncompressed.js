define("epi-addon-tinymce/plugins/epi-image-uploader/epi-image-uploader", [
    "dojo/_base/lang",
    "dojo/when",
    "dojo/on",
    "dojo/_base/window",
    "dojo/dom-construct",
    "dojo/topic",
    "epi-addon-tinymce/tinymce-loader",
    "epi/dependency",
    "epi/shell/_ContextMixin",
    "epi-cms/widget/viewmodel/MultipleFileUploadViewModel",
    "epi-cms/widget/MultipleFileUpload",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.uploadmultiplefiles"
], function (
    lang,
    when,
    on,
    win,
    domConstruct,
    topic,
    tinymce,
    dependency,
    _ContextMixin,
    MultipleFileUploadViewModel,
    MultipleFileUpload,
    resources
) {
    function imageUploadHandler(blobInfo, success, editor) {
        var context = new _ContextMixin();
        var registry = dependency.resolve("epi.storeregistry");
        var store = registry.get("epi.cms.contentdata");
        var structureStore = registry.get("epi.cms.content.light");
        var imgTemplate = "img[src='{0}']";
        var generateFileName = false;

        function destroyTemporaryImageObject(blobInfo) {
            var img = editor.dom.select(lang.replace(imgTemplate, [blobInfo.blobUri()]));
            if (img.length === 1) {
                editor.focus();
                domConstruct.destroy(img[0]);
                editor.fire("Change");
                return true;
            }
            return false;
        }


        function ensureUniqueFilename(fileName) {
            if (!generateFileName) {
                return fileName;
            }

            // TinyMCE uses a default filename when pasting a raw image, in such case we should make the filename unique
            // or otherwise every subsequent paste operation will override the previous one.
            // This issue is reported in the TinyMCE repository #3852
            return "image" + Math.random().toString(36).slice(8) + ".png";
        }

        // Get contentlink from the widget, in the case of inline editing.
        // Otherwise get from the context.
        function getContentId() {
            if (editor._contentLink != null) {
                return editor._contentLink;
            } else {
                return when(context.getCurrentContext()).then(function (content) {
                    return content.id;
                });
            }
        }

        editor.on("dragover", function (e) {
            editor.fire("FileDragged");
            e.stopPropagation();
        });

        editor.on("paste", function () {
            generateFileName = true;
        });

        var dragOverHandle = on(win.doc, "dragover", function () {
            editor.fire("FileDragging");
        });

        var dragLeaveHandle = on(win.doc, "dragleave", function () {
            editor.fire("FileStoppedDragging");
        });

        editor.on("remove", function () {
            dragOverHandle.remove();
            dragLeaveHandle.remove();
        });


        var uploader = new MultipleFileUpload({
            model: new MultipleFileUploadViewModel({
                store: structureStore,
                query: { query: "getchildren", allLanguages: true }
            }),
            createAsLocalAsset: true
        });

        function resetUploader() {
            generateFileName = false;
            uploader.destroyRecursive();
        }

        function onUploadFailed(status) {
            if (destroyTemporaryImageObject(blobInfo)) {
                // when the temporary image was not added to the editor,
                // then failure should not be called because it contains method
                // that won't be resolved properly
                //failure(status);
            }
        }

        return new window.Promise(function (resolve) {
            var uploadCompleteHandle = uploader.on("uploadComplete", function (files) {
                uploadCompleteHandle.remove();

                if (!files || files.length <= 0) {
                    onUploadFailed();
                    resetUploader();
                    tinymce.activeEditor.windowManager.close();
                    return;
                }

                var file = files[0];
                if (file.statusMessage) {
                    onUploadFailed(file.statusMessage);
                    resetUploader();
                } else {
                    when(store.get(file.contentLink)).then(function (content) {
                        topic.publish("/epi/cms/contentdata/updated", {
                            contentLink: content.contentLink
                        });

                        var MORE_THAN_100_PERCENT = 101;
                        success(MORE_THAN_100_PERCENT);
                        var assetsFolderLink = uploader.model.query.references[0];
                        topic.publish("/epi/cms/upload", assetsFolderLink);
                        editor.fire("Change");
                        resolve(content.previewUrl);
                    }).otherwise(function () {
                        onUploadFailed(resources.uploadform.errormessage);
                    }).always(function () {
                        resetUploader();
                    });
                }
            });

            when(getContentId()).then(function (contentId) {
                store.refresh(contentId).then(function (refreshedContent) {
                    uploader.model.query.references = [refreshedContent.assetsFolderLink];
                    uploader.set("uploadDirectory", contentId);
                    uploader.upload([tinymce.Env.ie ? blobInfo.blob() : new File([blobInfo.blob()], ensureUniqueFilename(blobInfo.filename()))]);
                });
            });
        });
    }

    return imageUploadHandler;
});
