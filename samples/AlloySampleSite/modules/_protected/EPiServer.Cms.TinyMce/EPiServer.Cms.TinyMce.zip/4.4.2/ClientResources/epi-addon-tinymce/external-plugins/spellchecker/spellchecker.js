/**
 * TinyMCE version 6.4.0 (TBD)
 */

(function () {
    'use strict';

    const Cell = initial => {
      let value = initial;
      const get = () => {
        return value;
      };
      const set = v => {
        value = v;
      };
      return {
        get,
        set
      };
    };

    var global$1 = tinymce.util.Tools.resolve('tinymce.PluginManager');

    const hasProPlugin = editor => {
      if (editor.hasPlugin('tinymcespellchecker', true)) {
        if (typeof window.console !== 'undefined' && window.console.log) {
          window.console.log(`Spell Checker Pro is incompatible with Spell Checker plugin! ` + `Remove 'spellchecker' from the 'plugins' option.`);
        }
        return true;
      } else {
        return false;
      }
    };

    const hasOwnProperty = Object.hasOwnProperty;
    const isEmpty = r => {
      for (const x in r) {
        if (hasOwnProperty.call(r, x)) {
          return false;
        }
      }
      return true;
    };

    var global = tinymce.util.Tools.resolve('tinymce.util.Tools');

    const fireSpellcheckStart = editor => editor.fire('SpellcheckStart');
    const fireSpellcheckEnd = editor => editor.fire('SpellcheckEnd');

    const getLanguages = editor => {
      const defaultLanguages = 'English=en,Danish=da,Dutch=nl,Finnish=fi,French=fr_FR,German=de,Italian=it,Polish=pl,Portuguese=pt_BR,Spanish=es,Swedish=sv';
      return editor.options.get("spellchecker_languages") || defaultLanguages;
    };
    const getLanguage = editor => {
      const defaultLanguage = editor.options.get("language") || "en";
      return editor.options.get("spellchecker_language") || defaultLanguage;
    };
    const getRpcUrl = editor => editor.options.get("spellchecker_rpc_url");
    const getSpellcheckerCallback = editor => editor.options.get("spellchecker_callback");
    const getSpellcheckerWordcharPattern = editor => {
      const defaultPattern = new RegExp('[^' + '\\s!"#$%&()*+,-./:;<=>?@[\\]^_{|}`' + '\xA7\xA9\xAB\xAE\xB1\xB6\xB7\xB8\xBB' + '\xBC\xBD\xBE\xBF\xD7\xF7\xA4\u201D\u201C\u201E\xA0\u2002\u2003\u2009' + ']+', 'g');
      return editor.options.get("spellchecker_wordchar_pattern") || defaultPattern;
    };

    const isContentEditableFalse = node => {
      return node && node.nodeType === 1 && node.contentEditable === 'false';
    };
    const DomTextMatcher = (node, editor) => {
      let m, matches = [];
      const dom = editor.dom;
      const blockElementsMap = editor.schema.getBlockElements();
      const hiddenTextElementsMap = editor.schema.getWhitespaceElements();
      const shortEndedElementsMap = editor.schema.getVoidElements();
      const createMatch = (m, data) => {
        if (!m[0]) {
          throw new Error('findAndReplaceDOMText cannot handle zero-length matches');
        }
        return {
          start: m.index,
          end: m.index + m[0].length,
          text: m[0],
          data
        };
      };
      const getText = node => {
        if (node.nodeType === 3) {
          return node.data;
        }
        if (hiddenTextElementsMap[node.nodeName] && !blockElementsMap[node.nodeName]) {
          return '';
        }
        if (isContentEditableFalse(node)) {
          return '\n';
        }
        let txt = '';
        if (blockElementsMap[node.nodeName] || shortEndedElementsMap[node.nodeName]) {
          txt += '\n';
        }
        if (node = node.firstChild) {
          do {
            txt += getText(node);
          } while (node = node.nextSibling);
        }
        return txt;
      };
      const stepThroughMatches = (node, matches, replaceFn) => {
        let startNode, endNode, startNodeIndex, endNodeIndex, innerNodes = [], atIndex = 0, curNode = node, matchLocation, matchIndex = 0;
        matches = matches.slice(0);
        matches.sort((a, b) => {
          return a.start - b.start;
        });
        matchLocation = matches.shift();
        out:
          while (true) {
            if (blockElementsMap[curNode.nodeName] || shortEndedElementsMap[curNode.nodeName] || isContentEditableFalse(curNode)) {
              atIndex++;
            }
            if (curNode.nodeType === 3) {
              if (!endNode && curNode.length + atIndex >= matchLocation.end) {
                endNode = curNode;
                endNodeIndex = matchLocation.end - atIndex;
              } else if (startNode) {
                innerNodes.push(curNode);
              }
              if (!startNode && curNode.length + atIndex > matchLocation.start) {
                startNode = curNode;
                startNodeIndex = matchLocation.start - atIndex;
              }
              atIndex += curNode.length;
            }
            if (startNode && endNode) {
              curNode = replaceFn({
                startNode,
                startNodeIndex,
                endNode,
                endNodeIndex,
                innerNodes,
                match: matchLocation.text,
                matchIndex
              });
              atIndex -= endNode.length - endNodeIndex;
              startNode = null;
              endNode = null;
              innerNodes = [];
              matchLocation = matches.shift();
              matchIndex++;
              if (!matchLocation) {
                break;
              }
            } else if ((!hiddenTextElementsMap[curNode.nodeName] || blockElementsMap[curNode.nodeName]) && curNode.firstChild) {
              if (!isContentEditableFalse(curNode)) {
                curNode = curNode.firstChild;
                continue;
              }
            } else if (curNode.nextSibling) {
              curNode = curNode.nextSibling;
              continue;
            }
            while (true) {
              if (curNode.nextSibling) {
                curNode = curNode.nextSibling;
                break;
              } else if (curNode.parentNode !== node) {
                curNode = curNode.parentNode;
              } else {
                break out;
              }
            }
          }
      };
      const genReplacer = callback => {
        const makeReplacementNode = (fill, matchIndex) => {
          const match = matches[matchIndex];
          if (!match.stencil) {
            match.stencil = callback(match);
          }
          const clone = match.stencil.cloneNode(false);
          clone.setAttribute('data-mce-index', '' + matchIndex);
          if (fill) {
            clone.appendChild(dom.doc.createTextNode(fill));
          }
          return clone;
        };
        return range => {
          let before;
          let after;
          let parentNode;
          const startNode = range.startNode;
          const endNode = range.endNode;
          const matchIndex = range.matchIndex;
          const doc = dom.doc;
          if (startNode === endNode) {
            const node = startNode;
            parentNode = node.parentNode;
            if (range.startNodeIndex > 0) {
              before = doc.createTextNode(node.data.substring(0, range.startNodeIndex));
              parentNode.insertBefore(before, node);
            }
            const el = makeReplacementNode(range.match, matchIndex);
            parentNode.insertBefore(el, node);
            if (range.endNodeIndex < node.length) {
              after = doc.createTextNode(node.data.substring(range.endNodeIndex));
              parentNode.insertBefore(after, node);
            }
            node.parentNode.removeChild(node);
            return el;
          }
          before = doc.createTextNode(startNode.data.substring(0, range.startNodeIndex));
          after = doc.createTextNode(endNode.data.substring(range.endNodeIndex));
          const elA = makeReplacementNode(startNode.data.substring(range.startNodeIndex), matchIndex);
          for (let i = 0, l = range.innerNodes.length; i < l; ++i) {
            const innerNode = range.innerNodes[i];
            const innerEl = makeReplacementNode(innerNode.data, matchIndex);
            innerNode.parentNode.replaceChild(innerEl, innerNode);
          }
          const elB = makeReplacementNode(endNode.data.substring(0, range.endNodeIndex), matchIndex);
          parentNode = startNode.parentNode;
          parentNode.insertBefore(before, startNode);
          parentNode.insertBefore(elA, startNode);
          parentNode.removeChild(startNode);
          parentNode = endNode.parentNode;
          parentNode.insertBefore(elB, endNode);
          parentNode.insertBefore(after, endNode);
          parentNode.removeChild(endNode);
          return elB;
        };
      };
      const unwrapElement = element => {
        const parentNode = element.parentNode;
        while (element.childNodes.length > 0) {
          parentNode.insertBefore(element.childNodes[0], element);
        }
        parentNode.removeChild(element);
      };
      const hasClass = elm => {
        return elm.className.indexOf('mce-spellchecker-word') !== -1;
      };
      const getWrappersByIndex = index => {
        const elements = node.getElementsByTagName('*'), wrappers = [];
        index = typeof index === 'number' ? '' + index : null;
        for (let i = 0; i < elements.length; i++) {
          const element = elements[i], dataIndex = element.getAttribute('data-mce-index');
          if (dataIndex !== null && dataIndex.length && hasClass(element)) {
            if (dataIndex === index || index === null) {
              wrappers.push(element);
            }
          }
        }
        return wrappers;
      };
      const indexOf = match => {
        let i = matches.length;
        while (i--) {
          if (matches[i] === match) {
            return i;
          }
        }
        return -1;
      };
      function filter(callback) {
        const filteredMatches = [];
        each((match, i) => {
          if (callback(match, i)) {
            filteredMatches.push(match);
          }
        });
        matches = filteredMatches;
        return this;
      }
      function each(callback) {
        for (let i = 0, l = matches.length; i < l; i++) {
          if (callback(matches[i], i) === false) {
            break;
          }
        }
        return this;
      }
      function wrap(callback) {
        if (matches.length) {
          stepThroughMatches(node, matches, genReplacer(callback));
        }
        return this;
      }
      function find(regex, data) {
        if (text && regex.global) {
          while (m = regex.exec(text)) {
            matches.push(createMatch(m, data));
          }
        }
        return this;
      }
      function unwrap(match) {
        let i;
        const elements = getWrappersByIndex(match ? indexOf(match) : null);
        i = elements.length;
        while (i--) {
          unwrapElement(elements[i]);
        }
        return this;
      }
      const matchFromElement = element => {
        return matches[element.getAttribute('data-mce-index')];
      };
      const elementFromMatch = match => {
        return getWrappersByIndex(indexOf(match))[0];
      };
      function add(start, length, data) {
        matches.push({
          start,
          end: start + length,
          text: text.substr(start, length),
          data
        });
        return this;
      }
      const rangeFromMatch = match => {
        const wrappers = getWrappersByIndex(indexOf(match));
        const rng = editor.dom.createRng();
        rng.setStartBefore(wrappers[0]);
        rng.setEndAfter(wrappers[wrappers.length - 1]);
        return rng;
      };
      const replace = (match, text) => {
        const rng = rangeFromMatch(match);
        rng.deleteContents();
        if (text.length > 0) {
          rng.insertNode(editor.dom.doc.createTextNode(text));
        }
        return rng;
      };
      function reset() {
        matches.splice(0, matches.length);
        unwrap();
        return this;
      }
      const text = getText(node);
      return {
        text,
        matches,
        each,
        filter,
        reset,
        matchFromElement,
        elementFromMatch,
        find,
        add,
        wrap,
        unwrap,
        replace,
        rangeFromMatch,
        indexOf
      };
    };

    const sendPost = async (url = '', data = {}) => {
      const response = await fetch(url, {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        redirect: 'follow',
        referrerPolicy: 'no-referrer',
        body: JSON.stringify(data)
      });
      return response.json();
    };
    const getTextMatcher = (editor, textMatcherState) => {
      if (!textMatcherState.get()) {
        const textMatcher = DomTextMatcher(editor.getBody(), editor);
        textMatcherState.set(textMatcher);
      }
      return textMatcherState.get();
    };
    const defaultSpellcheckCallback = (editor, pluginUrl, currentLanguageState) => {
      return (method, text, doneCallback, errorCallback) => {
        const data = {
          method,
          lang: currentLanguageState.get()
        };
        let postData = '';
        data[method === 'addToDictionary' ? 'word' : 'text'] = text;
        global.each(data, (value, key) => {
          if (postData) {
            postData += '&';
          }
          postData += key + '=' + encodeURIComponent(value);
        });
        sendPost(getRpcUrl(editor), postData).then(parseResult => {
          if (!parseResult) {
            const message = editor.translate(`Server response wasn't proper JSON.`);
            errorCallback(message);
          } else if (parseResult.error) {
            errorCallback(parseResult.error);
          } else {
            doneCallback(parseResult);
          }
        }).catch(() => {
          const message = editor.translate('The spelling service was not found: (') + getRpcUrl(editor) + editor.translate(')');
          errorCallback(message);
        });
      };
    };
    const sendRpcCall = (editor, pluginUrl, currentLanguageState, name, data, successCallback, errorCallback) => {
      const userSpellcheckCallback = getSpellcheckerCallback(editor);
      const spellCheckCallback = userSpellcheckCallback ? userSpellcheckCallback : defaultSpellcheckCallback(editor, pluginUrl, currentLanguageState);
      spellCheckCallback.call(editor.plugins.spellchecker, name, data, successCallback, errorCallback);
    };
    const spellcheck = (editor, pluginUrl, startedState, textMatcherState, lastSuggestionsState, currentLanguageState) => {
      if (finish(editor, startedState, textMatcherState)) {
        return;
      }
      const errorCallback = message => {
        editor.notificationManager.open({
          text: message,
          type: 'error'
        });
        editor.setProgressState(false);
        finish(editor, startedState, textMatcherState);
      };
      const successCallback = data => {
        markErrors(editor, startedState, textMatcherState, lastSuggestionsState, data);
      };
      editor.setProgressState(true);
      sendRpcCall(editor, pluginUrl, currentLanguageState, 'spellcheck', getTextMatcher(editor, textMatcherState).text, successCallback, errorCallback);
      editor.focus();
    };
    const checkIfFinished = (editor, startedState, textMatcherState) => {
      if (!editor.dom.select('span.mce-spellchecker-word').length) {
        finish(editor, startedState, textMatcherState);
      }
    };
    const addToDictionary = (editor, pluginUrl, startedState, textMatcherState, currentLanguageState, word, spans) => {
      editor.setProgressState(true);
      sendRpcCall(editor, pluginUrl, currentLanguageState, 'addToDictionary', word, () => {
        editor.setProgressState(false);
        editor.dom.remove(spans, true);
        checkIfFinished(editor, startedState, textMatcherState);
      }, message => {
        editor.notificationManager.open({
          text: message,
          type: 'error'
        });
        editor.setProgressState(false);
      });
    };
    const ignoreWord = (editor, startedState, textMatcherState, word, spans, all) => {
      editor.selection.collapse();
      if (all) {
        global.each(editor.dom.select('span.mce-spellchecker-word'), span => {
          if (span.getAttribute('data-mce-word') === word) {
            editor.dom.remove(span, true);
          }
        });
      } else {
        editor.dom.remove(spans, true);
      }
      checkIfFinished(editor, startedState, textMatcherState);
    };
    const finish = (editor, startedState, textMatcherState) => {
      const bookmark = editor.selection.getBookmark();
      getTextMatcher(editor, textMatcherState).reset();
      editor.selection.moveToBookmark(bookmark);
      textMatcherState.set(null);
      if (startedState.get()) {
        startedState.set(false);
        fireSpellcheckEnd(editor);
        return true;
      }
      return false;
    };
    const getElmIndex = elm => {
      const value = elm.getAttribute('data-mce-index');
      if (typeof value === 'number') {
        return '' + value;
      }
      return value;
    };
    const findSpansByIndex = (editor, index) => {
      const spans = [];
      const nodes = global.toArray(editor.getBody().getElementsByTagName('span'));
      if (nodes.length) {
        for (let i = 0; i < nodes.length; i++) {
          const nodeIndex = getElmIndex(nodes[i]);
          if (nodeIndex === null || !nodeIndex.length) {
            continue;
          }
          if (nodeIndex === index.toString()) {
            spans.push(nodes[i]);
          }
        }
      }
      return spans;
    };
    const markErrors = (editor, startedState, textMatcherState, lastSuggestionsState, data) => {
      const hasDictionarySupport = !!data.dictionary;
      const suggestions = data.words;
      editor.setProgressState(false);
      if (isEmpty(suggestions)) {
        const message = editor.translate('No misspellings found.');
        editor.notificationManager.open({
          text: message,
          type: 'info',
          timeout: 2000
        });
        startedState.set(false);
        return;
      }
      lastSuggestionsState.set({
        suggestions,
        hasDictionarySupport
      });
      const bookmark = editor.selection.getBookmark();
      getTextMatcher(editor, textMatcherState).find(getSpellcheckerWordcharPattern(editor)).filter(match => {
        return !!suggestions[match.text];
      }).wrap(match => {
        return editor.dom.create('span', {
          'class': 'mce-spellchecker-word',
          'aria-invalid': 'spelling',
          'data-mce-bogus': 1,
          'data-mce-word': match.text
        });
      });
      editor.selection.moveToBookmark(bookmark);
      startedState.set(true);
      fireSpellcheckStart(editor);
    };

    const get = (editor, startedState, lastSuggestionsState, textMatcherState, currentLanguageState) => {
      const getWordCharPattern = () => {
        return getSpellcheckerWordcharPattern(editor);
      };
      const markErrors$1 = data => {
        markErrors(editor, startedState, textMatcherState, lastSuggestionsState, data);
      };
      return {
        getTextMatcher: textMatcherState.get,
        getWordCharPattern,
        markErrors: markErrors$1,
        getLanguage: currentLanguageState.get
      };
    };

    const register$1 = (editor, pluginUrl, startedState, textMatcherState, lastSuggestionsState, currentLanguageState) => {
      editor.addCommand('mceSpellCheck', () => {
        spellcheck(editor, pluginUrl, startedState, textMatcherState, lastSuggestionsState, currentLanguageState);
      });
    };

    const spellcheckerEvents = 'SpellcheckStart SpellcheckEnd';
    const buildMenuItems = (listName, languageValues) => {
      const items = [];
      global.each(languageValues, languageValue => {
        items.push({
          selectable: true,
          text: languageValue.name,
          data: languageValue.value
        });
      });
      return items;
    };
    const getItems = editor => {
      return global.map(getLanguages(editor).split(','), langPair => {
        const langPairs = langPair.split('=');
        return {
          name: langPairs[0],
          value: langPairs[1]
        };
      });
    };
    const register = (editor, pluginUrl, startedState, textMatcherState, currentLanguageState, lastSuggestionsState) => {
      const languageMenuItems = buildMenuItems('Language', getItems(editor));
      const startSpellchecking = () => {
        spellcheck(editor, pluginUrl, startedState, textMatcherState, lastSuggestionsState, currentLanguageState);
      };
      const buttonArgs = {
        tooltip: 'Spellcheck',
        onAction: startSpellchecking,
        icon: 'spell-check',
        onSetup: buttonApi => {
          const setButtonState = () => {
            buttonApi.setActive(startedState.get());
          };
          editor.on(spellcheckerEvents, setButtonState);
          return () => {
            editor.off(spellcheckerEvents, setButtonState);
          };
        }
      };
      const splitButtonArgs = {
        ...buttonArgs,
        type: 'splitbutton',
        select: value => value === currentLanguageState.get(),
        fetch: callback => {
          const items = global.map(languageMenuItems, languageItem => ({
            type: 'choiceitem',
            value: languageItem.data,
            text: languageItem.text
          }));
          callback(items);
        },
        onItemAction: (splitButtonApi, value) => {
          currentLanguageState.set(value);
        }
      };
      if (languageMenuItems.length > 1) {
        editor.ui.registry.addSplitButton('spellchecker', splitButtonArgs);
      } else {
        editor.ui.registry.addToggleButton('spellchecker', buttonArgs);
      }
      editor.ui.registry.addToggleMenuItem('spellchecker', {
        text: 'Spellcheck',
        icon: 'spell-check',
        onSetup: menuApi => {
          menuApi.setActive(startedState.get());
          const setMenuItemCheck = () => {
            menuApi.setActive(startedState.get());
          };
          editor.on(spellcheckerEvents, setMenuItemCheck);
          return () => {
            editor.off(spellcheckerEvents, setMenuItemCheck);
          };
        },
        onAction: startSpellchecking
      });
    };

    const ignoreAll = true;
    const getSuggestions = (editor, pluginUrl, lastSuggestionsState, startedState, textMatcherState, currentLanguageState, word, spans) => {
      const items = [];
      const suggestions = lastSuggestionsState.get().suggestions[word];
      global.each(suggestions, suggestion => {
        items.push({
          text: suggestion,
          onAction: () => {
            editor.insertContent(editor.dom.encode(suggestion));
            editor.dom.remove(spans);
            checkIfFinished(editor, startedState, textMatcherState);
          }
        });
      });
      const hasDictionarySupport = lastSuggestionsState.get().hasDictionarySupport;
      if (hasDictionarySupport) {
        items.push({ type: 'separator' });
        items.push({
          text: 'Add to dictionary',
          onAction: () => {
            addToDictionary(editor, pluginUrl, startedState, textMatcherState, currentLanguageState, word, spans);
          }
        });
      }
      items.push.apply(items, [
        { type: 'separator' },
        {
          text: 'Ignore',
          onAction: () => {
            ignoreWord(editor, startedState, textMatcherState, word, spans);
          }
        },
        {
          text: 'Ignore all',
          onAction: () => {
            ignoreWord(editor, startedState, textMatcherState, word, spans, ignoreAll);
          }
        }
      ]);
      return items;
    };
    const setup = (editor, pluginUrl, lastSuggestionsState, startedState, textMatcherState, currentLanguageState) => {
      const update = element => {
        const target = element;
        if (target.className === 'mce-spellchecker-word') {
          const spans = findSpansByIndex(editor, getElmIndex(target));
          if (spans.length > 0) {
            const rng = editor.dom.createRng();
            rng.setStartBefore(spans[0]);
            rng.setEndAfter(spans[spans.length - 1]);
            editor.selection.setRng(rng);
            return getSuggestions(editor, pluginUrl, lastSuggestionsState, startedState, textMatcherState, currentLanguageState, target.getAttribute('data-mce-word'), spans);
          } else {
            return [];
          }
        } else {
          return [];
        }
      };
      let spec = { update };
      editor.ui.registry.addContextMenu('spellchecker', spec);
    };

    var Plugin = () => {
      global$1.add('spellchecker', (editor, pluginUrl) => {
        if (hasProPlugin(editor) === false) {
          const startedState = Cell(false);
          const currentLanguageState = Cell(getLanguage(editor));
          const textMatcherState = Cell(null);
          const lastSuggestionsState = Cell(null);
          register(editor, pluginUrl, startedState, textMatcherState, currentLanguageState, lastSuggestionsState);
          setup(editor, pluginUrl, lastSuggestionsState, startedState, textMatcherState, currentLanguageState);
          register$1(editor, pluginUrl, startedState, textMatcherState, lastSuggestionsState, currentLanguageState);
          return get(editor, startedState, lastSuggestionsState, textMatcherState, currentLanguageState);
        } else {
          return undefined;
        }
      });
    };

    Plugin();

})();
