define("epi-addon-tinymce/plugins/epi-block-tools/epi-block-tools", [
    "dojo/topic",
    "epi",
    "epi-addon-tinymce/tinymce-loader",
    "epi-addon-tinymce/ContentService",
    "epi-cms/contentediting/command/BlockInlineEdit",
    "epi/i18n!epi/cms/nls/episerver.cms.tinymce.plugins.epiblocktools"
], function (topic, epi, tinymce, ContentService, BlockInlineEdit, pluginResources) {

    tinymce.PluginManager.add("epi-block-tools", function (editor) {
        function isBlock(el) {
            var selectorMatched = editor.dom.is(el, "div.epi-contentfragment:not([mceItem])");
            return selectorMatched;
        }

        function addToolbars() {
            editor.addContextToolbar(
                isBlock,
                "epi-gotoblock"
            );
        }

        var contentService = new ContentService();
        var blockInlineEditCommand = new BlockInlineEdit({
            suppressOverlayAdjustments: editor.isFullScreen
        });

        var currentContent = null;
        var updateButton = function (button) {
            var selectedElement = editor.selection.getNode();

            if (isBlock(selectedElement)) {
                var contentLink = selectedElement.dataset && selectedElement.dataset.contentlink;
                if (!contentLink) {
                    button.disabled(true);
                    button.settings.tooltip = pluginResources.error;
                    return;
                }
                contentService.getContent(contentLink)
                    .then(function (content) {
                        currentContent = content;
                        return contentService.getPathToContent(content);
                    })
                    .then(function (imagePath) {
                        button.settings.tooltip = imagePath;
                        button.disabled(false);

                        if (currentContent.capabilities.isLocalContent) {
                            blockInlineEditCommand.set("model", currentContent);
                            var handle = blockInlineEditCommand.watch("canExecute", function (name, oldValue, newValue) {
                                handle.remove();
                                handle = null;
                                button.disabled(!newValue);
                            });
                        }
                    })
                    .otherwise(function () {
                        button.disabled(true);
                        button.settings.tooltip = pluginResources.error;
                    });
            }
        };

        editor.on("FullscreenStateChanged", function (event) {
            this.isFullScreen = event.state;
        });

        // Register buttons
        editor.addButton("epi-gotoblock", {
            text: epi.resources.action.edit,
            icon: false,
            //Needs to be set so that we can update it
            tooltip: "default tooltip",
            onclick: function () {
                editor.fire("blur");
                if (!currentContent.capabilities.isLocalContent) {
                    topic.publish("/epi/shell/context/request", { uri: currentContent.uri }, { sender: this });
                    return;
                }

                if (blockInlineEditCommand && blockInlineEditCommand.get("canExecute")) {
                    blockInlineEditCommand.execute();
                }
            },
            onPostRender: function () {
                //Set tooltip the first time tinymce starts after browser refresh
                updateButton(this);

                editor.on("NodeChange", function (e) {
                    //Update the tooltip
                    updateButton(this);
                }.bind(this));
            }
        });

        addToolbars();

        return {
            getMetadata: function () {
                return {
                    name: "Block tools (epi)",
                    url: "https://www.episerver.com"
                };
            }
        };
    });
});
